#!/bin/bash

#set -e

sudo rm -rvf out/ 
sudo rm -rvf work/


echo "CLEANED ..."
